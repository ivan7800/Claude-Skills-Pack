# Pull request

## Summary

Describe the change.

## Checklist

- [ ] I ran `python scripts/validate-skills-pack.py`.
- [ ] I updated docs if needed.
- [ ] I did not include secrets, logs, private files or generated ZIPs.
- [ ] The change improves a real workflow.
