# I. Roig Claude Skills Pack

![Version](https://img.shields.io/badge/version-1.2.1-blue) ![License](https://img.shields.io/badge/license-MIT-green) ![Claude%20Code%20Skills](https://img.shields.io/badge/Claude%20Code-Skills-orange)

Pack de Skills para Claude/Claude Code orientado a proyectos reales: apps HTML/JS para GitHub, PWAs, depuración, seguridad, releases, prompts para Claude, revisión narrativa, testing, compatibilidad iPhone/Safari y voz oscura de marca.

Versión: **1.2.1**

## Veredicto de diseño

Este pack está pensado para convertir instrucciones repetidas en herramientas reutilizables. No sustituye las pruebas reales, pero obliga a Claude a seguir métodos más sólidos: inspeccionar, diagnosticar, corregir y verificar.

## Qué contiene

| Skill | Comando en Claude Code | Para qué sirve |
|---|---|---|
| accessibility-basic-auditor | `/accessibility-basic-auditor` | Audita accesibilidad básica de apps web: contraste, teclado, foco, labels, semántica HTML, aria y legibilidad móvil. |
| ai-integration-planner | `/ai-integration-planner` | Diseña integración de IA en apps locales o web: API key del usuario, Ollama local, modo sin IA, privacidad, costes y arquitectura seria. |
| brand-voice-dark | `/brand-voice-dark` | Mantiene una voz de marca oscura, elegante y coherente para webs de autor, apps góticas, copy promocional y proyectos creativos. |
| claude-skill-builder | `/claude-skill-builder` | Convierte un prompt repetido o flujo de trabajo en una Skill de Claude Code con SKILL.md, descripción, criterios de uso, checklist y ejemplos. |
| codebase-context-loader | `/codebase-context-loader` | Carga contexto técnico de un repositorio antes de auditar o modificar: estructura, archivos clave, package.json, manifest, service worker y estado Git. |
| github-app-auditor | `/github-app-auditor` | Audita apps HTML/CSS/JavaScript, PWAs o proyectos frontend antes de subirlos a GitHub/GitHub Pages. Úsalo para revisar si una app local está lista, si falla, si parece profesional o si hay bugs. |
| github-pages-deploy-check | `/github-pages-deploy-check` | Comprueba si un proyecto web está preparado para publicarse en GitHub Pages: rutas relativas, assets, manifest, service worker, base path y README. |
| local-storage-data-auditor | `/local-storage-data-auditor` | Audita datos guardados en localStorage/sessionStorage/IndexedDB: privacidad, borrado, migraciones, tamaño, seguridad y UX. |
| loop-engineering-agent | `/loop-engineering-agent` | Ejecuta un ciclo iterativo de generación, auditoría, corrección y verificación para mejorar código, textos, prompts o productos. |
| novelist-editor-hard | `/novelist-editor-hard` | Audita novelas, capítulos, escenas y prosa con criterio editorial duro: estructura, ritmo, tensión, voz, diálogo, redundancias y publicabilidad. |
| prompt-optimizer-claude | `/prompt-optimizer-claude` | Convierte peticiones desordenadas en prompts profesionales para Claude, con objetivo, contexto, archivos, criterios de éxito, pasos y formato de salida. |
| pwa-offline-auditor | `/pwa-offline-auditor` | Revisa manifest, service worker, caché, instalación, offline-first y compatibilidad móvil de una PWA o app local. |
| readme-github-pro | `/readme-github-pro` | Genera o mejora un README profesional para proyectos GitHub, con instalación, uso, capturas, privacidad, estructura, roadmap y GitHub Pages. |
| release-finalizer | `/release-finalizer` | Prepara una versión final seria para GitHub: limpieza, estructura, README, changelog, licencia, seguridad, pruebas y checklist de release. |
| safari-ios-compat-auditor | `/safari-ios-compat-auditor` | Revisa compatibilidad con Safari/iPhone: APIs no soportadas, PWA, viewport, botones, audio, compartir, copiar al portapapeles, localStorage y responsive. |
| security-privacy-review | `/security-privacy-review` | Revisa privacidad y seguridad en apps locales, formularios, localStorage, claves API, datos sensibles, XSS, dependencias y exposición accidental. |
| systematic-debugger | `/systematic-debugger` | Depura errores de forma sistemática: reproducir, aislar causa raíz, corregir, probar y evitar arreglos a ciegas. |
| test-plan-generator | `/test-plan-generator` | Genera un plan de pruebas manuales y técnicas para apps web/locales antes de declararlas versión final. |
| ui-ux-mobile-auditor | `/ui-ux-mobile-auditor` | Audita interfaz, experiencia móvil, responsive, accesibilidad básica, legibilidad, jerarquía visual y microcopy. |


## Estado GitHub

Este repositorio está preparado para publicarse en GitHub: incluye licencia, changelog, guía de instalación, guía de uso, contribución, política de seguridad, plantillas de issues, plantilla de pull request y workflow de validación.

Para subirlo:

```bash
git init
git add .
git commit -m "Initial release: I. Roig Claude Skills Pack v1.2.1"
git branch -M main
git remote add origin https://github.com/TU-USUARIO/i-roig-claude-skills-pack.git
git push -u origin main
```

## Instalación personal en Claude Code

Copia las carpetas de `skills/` dentro de:

```bash
~/.claude/skills/
```

En Windows suele equivaler a:

```powershell
$env:USERPROFILE\.claude\skills
```

O ejecuta:

```powershell
.\install-windows.ps1
```

En macOS/Linux:

```bash
chmod +x install-macos-linux.sh
./install-macos-linux.sh
```

## Instalación solo en un proyecto

Desde la carpeta del pack, abre terminal dentro del repo donde quieres instalar las Skills y ejecuta:

```powershell
.\install-project.ps1
```

O en macOS/Linux:

```bash
./install-project.sh
```

La estructura final será:

```text
tu-proyecto/
  .claude/
    skills/
      github-app-auditor/
        SKILL.md
```

## Flujo recomendado para tus apps

```text
/codebase-context-loader Primero entiende este repo.
/github-app-auditor Revisa si está listo para GitHub.
/systematic-debugger Corrige los bugs críticos sin parches a ciegas.
/pwa-offline-auditor Revisa manifest y service worker si es PWA.
/security-privacy-review Comprueba claves, localStorage y datos sensibles.
/test-plan-generator Crea las pruebas finales.
/release-finalizer Déjalo como release candidate.
```

## Flujo recomendado para novelas

```text
/novelist-editor-hard Revisa este capítulo con auditoría dura.
/brand-voice-dark Ajusta textos de web, sinopsis o landing con voz oscura elegante.
```

## Validar el pack

```bash
python scripts/validate-skills-pack.py
```

## Carpetas extra

```text
checklists/   Checklists reutilizables.
templates/    Plantillas de README y documentación.
scripts/      Validadores del propio pack.
```

## Nota importante

Las Skills no hacen magia. Funcionan mejor si Claude Code tiene acceso al repositorio completo y si después se hacen pruebas reales en navegador, móvil y consola. Para una app seria, usa siempre una Skill de auditoría + una Skill de pruebas + una Skill de release.

## Autor

Preparado para I. Roig.


## Documentación adicional

- `docs/INSTALLATION.md`: instalación personal y por proyecto.
- `docs/USAGE.md`: comandos prácticos para usar las Skills.
- `docs/GITHUB-PUBLISHING.md`: pasos para crear el repositorio y publicar la primera release.
- `examples/COMMANDS.md`: ejemplos rápidos de invocación.
- `RELEASE-CHECKLIST.md`: lista final antes de publicar una versión.

## Aviso

Este proyecto no está afiliado a Anthropic. Es un pack independiente de instrucciones y utilidades para trabajar mejor con Claude Code.
