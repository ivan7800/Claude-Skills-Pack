# Release checklist

Before publishing a release:

- [ ] `VERSION` matches `skills-manifest.json`.
- [ ] `CHANGELOG.md` includes the new version.
- [ ] `python scripts/validate-skills-pack.py` passes.
- [ ] README installation commands are still correct.
- [ ] No `.zip`, `.log`, `.bak`, `.tmp`, credentials or private data are committed.
- [ ] Install scripts are tested or reviewed.
- [ ] GitHub Actions validation passes.
- [ ] Release ZIP is generated from a clean checkout.

Suggested tag:

```bash
git tag v1.2.1
git push origin v1.2.1
```
